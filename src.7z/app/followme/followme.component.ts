import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-followme',
  templateUrl: './followme.component.html',
  styleUrls: ['./followme.component.css']
})
export class FollowmeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
