import { Route } from '@angular/router';
import { FollowmeComponent } from './followme.component';

export const FollowmeRoutes: Route[] = [
  	{ path: 'followme', component: FollowmeComponent}
]