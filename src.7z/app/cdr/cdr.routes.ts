import { Route } from '@angular/router';
import { CdrComponent } from './cdr.component';

export const CdrRoutes: Route[] = [
  	{ path: 'cdr', component: CdrComponent}
]