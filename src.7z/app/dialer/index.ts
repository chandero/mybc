export * from './dialer.component';
export * from './dialer.module';