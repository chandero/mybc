import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialer',
  templateUrl: './dialer.component.html',
  styleUrls: ['./dialer.component.css']
})
export class DialerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
