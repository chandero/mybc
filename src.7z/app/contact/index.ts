export * from './contact.component';
export * from './contact.module';