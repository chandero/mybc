export * from './settings.component';
export * from './settings.routes';