import { Injectable, Optional } from '@angular/core';    
    
@Injectable()    
export class Conference_invitado {
    
    public coin_id: number;
    public coin_numero: string;
    public coin_tipo: number;
    public copr_id: number;

    constructor(){}
}