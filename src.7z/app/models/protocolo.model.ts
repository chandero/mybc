import { Injectable } from '@angular/core';

@Injectable() 
export class Protocolo {
    public prot_id: number;
	public prot_nombre: string;
}